import React from "react";

export const Button = () => {
  return (
    <center>
<button type="button" class="btn btn-outline-primary">Registrarse</button>
<button type="button" class="btn btn-outline-secondary">Iniciar sesión</button></center>

    );
  };
  