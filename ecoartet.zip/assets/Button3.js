import React from "react";

export const Button3 = () => {
  return (

    <button type="button" class="btn btn-primary btn-lg btn-block">Continuar con google</button>

    );
  };

